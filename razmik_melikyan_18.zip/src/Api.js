import axios from "axios";


class Api {
    static getNotes(id) {
        return axios.get(`https://razmikreact.user.com/api/public/users/${id}/notes/`,
            {headers: {Authorization: 'Token tb4RDHco6FzwIXR7Rsw1cwxgejqp8d7yNdVKqdf6NUMxxPA5qdPFD3g4749Tjn0U'}})
    }
    static createUsers(id, body){
        return axios.post(`https://razmikreact.user.com/api/public/users/${id}/notes/`, body,
            {headers: {Authorization: 'Token tb4RDHco6FzwIXR7Rsw1cwxgejqp8d7yNdVKqdf6NUMxxPA5qdPFD3g4749Tjn0U'}})
    }
    static deleteNote(noteId, userId){
        return axios.delete(`https://razmikreact.user.com/api/public/users/${userId}/notes/${noteId}`,
            {headers: {Authorization: 'Token tb4RDHco6FzwIXR7Rsw1cwxgejqp8d7yNdVKqdf6NUMxxPA5qdPFD3g4749Tjn0U'}})
    }
    static updateNote(noteId, userId, body){
        return axios.patch(`https://razmikreact.user.com/api/public/users/${userId}/notes/${noteId}/`, body,
            {headers: {Authorization: 'Token tb4RDHco6FzwIXR7Rsw1cwxgejqp8d7yNdVKqdf6NUMxxPA5qdPFD3g4749Tjn0U'}})
    }
}

export default Api;
