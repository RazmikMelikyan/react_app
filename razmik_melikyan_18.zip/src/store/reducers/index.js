import { combineReducers } from "redux";
import notes from "./notes";


const reducers = combineReducers({
    notes
})

export default reducers;